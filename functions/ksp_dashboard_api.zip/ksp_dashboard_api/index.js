'use strict';

const catalyst = require('zcatalyst-sdk-node');

module.exports = async (req, res) => {
    try {
        const app = catalyst.initialize(req);
        const zcql = app.zcql();

        const url = req.url.split('?')[0];

        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Access-Control-Allow-Origin', '*');

        // =========================
        // HOME
        // =========================
        if (url === '/' || url === '') {
            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                message: 'KSP Crime Intelligence Dashboard API',
                endpoints: [
                    '/summary',
                    '/districts',
                    '/yearly',
                    '/crime-heads',
                    '/crime-types',
                    '/gravity-offences',
                    '/case-status',
                    '/prediction'
                ]
            }));

            return;
        }

        // =========================
        // SUMMARY API
        // =========================
        if (url === '/summary') {

            const totalFirQuery =
                'SELECT COUNT(ROWID) FROM CaseMaster';

            const totalFirResult =
                await zcql.executeZCQLQuery(totalFirQuery);

            const totalFIRs = Number(
                totalFirResult[0]
                    .CaseMaster['COUNT(ROWID)']
            );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                data: {
                    totalFIRs: totalFIRs
                }
            }));

            return;
        }

        // =========================
        // DISTRICT WISE FIR API
        // =========================
        if (url === '/districts') {

            const query = `
                SELECT
                    District.DistrictName,
                    COUNT(CaseMaster.ROWID)
                FROM CaseMaster
                INNER JOIN Unit
                    ON CaseMaster.PoliceStationID = Unit.ROWID
                INNER JOIN District
                    ON Unit.DistrictID = District.ROWID
                GROUP BY District.DistrictName
                ORDER BY COUNT(CaseMaster.ROWID) DESC
            `;

            const result =
                await zcql.executeZCQLQuery(query);

            const districts = result.map(row => ({
                districtName:
                    row.District.DistrictName,

                totalFIRs: Number(
                    row.CaseMaster['COUNT(ROWID)']
                )
            }));

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                count: districts.length,
                data: districts
            }));

            return;
        }

        // =========================
        // YEAR WISE FIR API
        // =========================
        if (url === '/yearly') {

            const years = [
                2020,
                2021,
                2022,
                2023,
                2024,
                2025,
                2026
            ];

            const yearly = [];

            for (const year of years) {

                const startDate =
                    `${year}-01-01 00:00:00`;

                const endDate =
                    `${year}-12-31 23:59:59`;

                const query = `
                    SELECT COUNT(ROWID)
                    FROM CaseMaster
                    WHERE CrimeRegisteredDate >= '${startDate}'
                    AND CrimeRegisteredDate <= '${endDate}'
                `;

                const result =
                    await zcql.executeZCQLQuery(query);

                const totalFIRs = Number(
                    result[0]
                        .CaseMaster['COUNT(ROWID)']
                );

                yearly.push({
                    year: year,
                    totalFIRs: totalFIRs
                });
            }

            const calculatedTotal = yearly.reduce(
                (sum, item) =>
                    sum + item.totalFIRs,
                0
            );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                calculatedTotal: calculatedTotal,
                data: yearly
            }));

            return;
        }

        // =========================
        // CRIME HEAD WISE FIR API
        // =========================
        if (url === '/crime-heads') {

            const query = `
                SELECT
                    CrimeHead.CrimeGroupName,
                    COUNT(CaseMaster.ROWID)
                FROM CaseMaster
                INNER JOIN CrimeHead
                    ON CaseMaster.CrimeMajorHeadID = CrimeHead.ROWID
                GROUP BY CrimeHead.CrimeGroupName
                ORDER BY COUNT(CaseMaster.ROWID) DESC
            `;

            const result =
                await zcql.executeZCQLQuery(query);

            const crimeHeads = result.map(row => ({
                crimeGroupName:
                    row.CrimeHead.CrimeGroupName,

                totalFIRs: Number(
                    row.CaseMaster['COUNT(ROWID)']
                )
            }));

            const calculatedTotal =
                crimeHeads.reduce(
                    (sum, item) =>
                        sum + item.totalFIRs,
                    0
                );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                calculatedTotal: calculatedTotal,
                count: crimeHeads.length,
                data: crimeHeads
            }));

            return;
        }

        // ==========================
        // CRIME TYPE WISE FIR API
        // ==========================
        if (url === '/crime-types') {

            const query = `
                SELECT
                    CrimeSubHead.CrimeHeadName,
                    COUNT(CaseMaster.ROWID)
                FROM CaseMaster
                INNER JOIN CrimeSubHead
                    ON CaseMaster.CrimeMinorHeadID = CrimeSubHead.ROWID
                GROUP BY CrimeSubHead.CrimeHeadName
                ORDER BY COUNT(CaseMaster.ROWID) DESC
            `;

            const result =
                await zcql.executeZCQLQuery(query);

            const crimeTypes = result.map(row => ({
                crimeType:
                    row.CrimeSubHead.CrimeHeadName,

                totalFIRs: Number(
                    row.CaseMaster['COUNT(ROWID)']
                )
            }));

            const calculatedTotal =
                crimeTypes.reduce(
                    (sum, item) =>
                        sum + item.totalFIRs,
                    0
                );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                calculatedTotal: calculatedTotal,
                count: crimeTypes.length,
                data: crimeTypes
            }));

            return;
        }

        // ==========================
        // GRAVITY OFFENCE API
        // ==========================
        if (url === '/gravity-offences') {

            const query = `
                SELECT
                    GravityOffence.GravityOffenceName,
                    COUNT(CaseMaster.ROWID)
                FROM CaseMaster
                INNER JOIN GravityOffence
                    ON CaseMaster.GravityOffenceID = GravityOffence.ROWID
                GROUP BY GravityOffence.GravityOffenceName
                ORDER BY COUNT(CaseMaster.ROWID) DESC
            `;

            const result =
                await zcql.executeZCQLQuery(query);

            const gravityOffences =
                result.map(row => ({
                    gravityOffenceName:
                        row.GravityOffence
                            .GravityOffenceName,

                    totalFIRs: Number(
                        row.CaseMaster['COUNT(ROWID)']
                    )
                }));

            const calculatedTotal =
                gravityOffences.reduce(
                    (sum, item) =>
                        sum + item.totalFIRs,
                    0
                );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                calculatedTotal: calculatedTotal,
                count: gravityOffences.length,
                data: gravityOffences
            }));

            return;
        }

        // ==========================
        // CASE STATUS API
        // ==========================
        if (url === '/case-status') {

            const query = `
                SELECT
                    CaseStatusMaster.CaseStatus,
                    COUNT(CaseMaster.ROWID)
                FROM CaseMaster
                INNER JOIN CaseStatusMaster
                    ON CaseMaster.CaseStatusID = CaseStatusMaster.ROWID
                GROUP BY CaseStatusMaster.CaseStatus
                ORDER BY COUNT(CaseMaster.ROWID) DESC
            `;

            const result =
                await zcql.executeZCQLQuery(query);

            const caseStatusData =
                result.map(row => ({
                    caseStatus:
                        row.CaseStatusMaster.CaseStatus,

                    totalFIRs: Number(
                        row.CaseMaster['COUNT(ROWID)']
                    )
                }));

            const calculatedTotal =
                caseStatusData.reduce(
                    (sum, item) =>
                        sum + item.totalFIRs,
                    0
                );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,
                calculatedTotal: calculatedTotal,
                count: caseStatusData.length,
                data: caseStatusData
            }));

            return;
        }

        // ==========================
        // FIR TREND PREDICTION API
        // LINEAR REGRESSION FORECAST
        // ==========================
        if (url === '/prediction') {

            const years = [
                2020,
                2021,
                2022,
                2023,
                2024,
                2025,
                2026
            ];

            const historicalData = [];

            for (const year of years) {

                const startDate =
                    `${year}-01-01 00:00:00`;

                const endDate =
                    `${year}-12-31 23:59:59`;

                const query = `
                    SELECT COUNT(ROWID)
                    FROM CaseMaster
                    WHERE CrimeRegisteredDate >= '${startDate}'
                    AND CrimeRegisteredDate <= '${endDate}'
                `;

                const result =
                    await zcql.executeZCQLQuery(query);

                const totalFIRs = Number(
                    result[0]
                        .CaseMaster['COUNT(ROWID)']
                );

                historicalData.push({
                    year: year,
                    totalFIRs: totalFIRs
                });
            }

            // ==========================
            // LINEAR REGRESSION
            // ==========================

            const n = historicalData.length;

            const sumX = historicalData.reduce(
                (sum, item) =>
                    sum + item.year,
                0
            );

            const sumY = historicalData.reduce(
                (sum, item) =>
                    sum + item.totalFIRs,
                0
            );

            const sumXY = historicalData.reduce(
                (sum, item) =>
                    sum +
                    (
                        item.year *
                        item.totalFIRs
                    ),
                0
            );

            const sumXSquare =
                historicalData.reduce(
                    (sum, item) =>
                        sum +
                        (
                            item.year *
                            item.year
                        ),
                    0
                );

            const denominator =
                (
                    n * sumXSquare
                ) -
                (
                    sumX * sumX
                );

            if (denominator === 0) {
                throw new Error(
                    'Unable to calculate prediction'
                );
            }

            const slope =
                (
                    (
                        n * sumXY
                    ) -
                    (
                        sumX * sumY
                    )
                ) /
                denominator;

            const intercept =
                (
                    sumY -
                    (
                        slope * sumX
                    )
                ) /
                n;

            const predictionYears = [
                2027,
                2028,
                2029
            ];

            const predictions =
                predictionYears.map(year => {

                    const predictedFIRs =
                        Math.max(
                            0,
                            Math.round(
                                (
                                    slope * year
                                ) +
                                intercept
                            )
                        );

                    return {
                        year: year,
                        predictedFIRs:
                            predictedFIRs
                    };
                });

            const latestActual =
                historicalData[
                    historicalData.length - 1
                ].totalFIRs;

            const nextPrediction =
                predictions[0].predictedFIRs;

            const predictedChangePercentage =
                latestActual === 0
                    ? 0
                    : Number(
                        (
                            (
                                (
                                    nextPrediction -
                                    latestActual
                                ) /
                                latestActual
                            ) *
                            100
                        ).toFixed(2)
                    );

            res.statusCode = 200;

            res.end(JSON.stringify({
                success: true,

                model:
                    'Linear Regression Trend Forecast',

                trainingPeriod:
                    '2020-2026',

                historicalData:
                    historicalData,

                predictions:
                    predictions,

                trend: {
                    slope:
                        Number(
                            slope.toFixed(2)
                        ),

                    direction:
                        slope > 0
                            ? 'Increasing'
                            : slope < 0
                                ? 'Decreasing'
                                : 'Stable',

                    predictedChangePercentage:
                        predictedChangePercentage
                }
            }));

            return;
        }

        // =========================
        // 404
        // =========================
        res.statusCode = 404;

        res.end(JSON.stringify({
            success: false,
            message: 'API endpoint not found'
        }));

    } catch (error) {

        console.error(error);

        res.statusCode = 500;

        res.end(JSON.stringify({
            success: false,
            message: error.message
        }));
    }
};